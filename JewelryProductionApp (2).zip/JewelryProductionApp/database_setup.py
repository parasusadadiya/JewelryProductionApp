import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATABASE_DIR = BASE_DIR / "database"
DATABASE_DIR.mkdir(exist_ok=True)

DATABASE = DATABASE_DIR / "production.db"


def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def _add_column_if_missing(connection, table, column_name, column_type):
    """Safely add a column to an existing table if it isn't there yet.

    Used so upgrading an older production.db (created before this
    consolidated setup existed) doesn't lose any data.
    """

    columns = [
        row[1]
        for row in connection.execute(
            f"PRAGMA table_info({table})"
        ).fetchall()
    ]

    if column_name not in columns:
        connection.execute(
            f"ALTER TABLE {table} ADD COLUMN {column_name} {column_type}"
        )


def init_db():
    """Create every table the app needs, and patch up any older
    database file so it has every column the current app expects.

    Safe to call every time the app starts - CREATE TABLE IF NOT EXISTS
    and the column checks above mean it never touches existing data.
    """

    connection = get_connection()

    # Customers
    connection.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Staff (for assigning production stages to a person)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            role TEXT,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Products (catalog of product/design names to pick from on an order)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Components (catalog of component names - prongs, clasp, chain, etc.)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS components (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # App-wide settings (single row). app_password_hash is seeded from the
    # APP_PASSWORD env var the first time the app runs - see app.py.
    connection.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            business_name TEXT,
            logo_path TEXT,
            app_password_hash TEXT,
            google_credentials_json TEXT,
            google_sheet_id TEXT,
            google_sync_enabled INTEGER NOT NULL DEFAULT 0,
            google_last_synced_at TEXT,
            google_last_sync_error TEXT,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.execute(
        "INSERT OR IGNORE INTO settings (id) VALUES (1)"
    )

    # Orders
    connection.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            order_type TEXT NOT NULL,
            product_id INTEGER,
            product_number TEXT,
            quantity INTEGER NOT NULL DEFAULT 1,
            order_date TEXT,
            due_date TEXT,
            photo_path TEXT,
            notes TEXT,
            metal_type TEXT,
            metal_purity TEXT,
            gross_weight REAL,
            net_weight REAL,
            order_price REAL,
            deposit_paid REAL NOT NULL DEFAULT 0,
            current_stage TEXT NOT NULL DEFAULT 'Customer Order',
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (customer_id)
                REFERENCES customers(id),
            FOREIGN KEY (product_id)
                REFERENCES products(id)
        )
    """)

    # Extra photos per order (beyond the single cover photo)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS order_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            photo_path TEXT NOT NULL,
            caption TEXT,
            uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (order_id)
                REFERENCES orders(id)
        )
    """)

    # Payments received against an order
    connection.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            payment_date TEXT NOT NULL,
            method TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (order_id)
                REFERENCES orders(id)
        )
    """)

    # Production stages
    connection.execute("""
        CREATE TABLE IF NOT EXISTS production_stages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            stage_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            started_at TEXT,
            completed_at TEXT,
            notes TEXT,
            assigned_staff_id INTEGER,

            FOREIGN KEY (order_id)
                REFERENCES orders(id),
            FOREIGN KEY (assigned_staff_id)
                REFERENCES staff(id)
        )
    """)

    # Rename the old "OC" stage to "QC" everywhere it appears, so old
    # orders' history/filters keep working under the new name.
    connection.execute(
        "UPDATE production_stages SET stage_name = 'QC' WHERE stage_name = 'OC'"
    )
    connection.execute(
        "UPDATE orders SET current_stage = 'QC' WHERE current_stage = 'OC'"
    )

    # A running log of notes per production stage (replaces the old
    # single overwrite-each-time notes field).
    connection.execute("""
        CREATE TABLE IF NOT EXISTS stage_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stage_id INTEGER NOT NULL,
            note TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT,

            FOREIGN KEY (stage_id)
                REFERENCES production_stages(id)
        )
    """)

    # Components used/needed on an order (picked from the catalog, or a
    # one-off custom name).
    connection.execute("""
        CREATE TABLE IF NOT EXISTS order_components (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            component_id INTEGER,
            custom_name TEXT,
            quantity REAL,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (order_id)
                REFERENCES orders(id),
            FOREIGN KEY (component_id)
                REFERENCES components(id)
        )
    """)

    # Vendor jobs for the Setting / Jewelry Work stage - an order can
    # have work split across multiple jewelers.
    connection.execute("""
        CREATE TABLE IF NOT EXISTS vendor_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            vendor_name TEXT NOT NULL,
            work_description TEXT,
            status TEXT NOT NULL DEFAULT 'Sent',
            sent_date TEXT,
            received_date TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (order_id)
                REFERENCES orders(id)
        )
    """)

    # Stone transactions (stones sent out / received for setting)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS stone_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            transaction_type TEXT,
            stone_type TEXT,
            shape TEXT,
            color TEXT,
            clarity TEXT,
            stone_description TEXT,
            vendor_name TEXT,
            quantity REAL,
            carat REAL,
            transaction_date TEXT,
            pickup_date TEXT,
            invoice_path TEXT,
            photo_path TEXT,
            reason TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (order_id)
                REFERENCES orders(id)
        )
    """)

    # To-Do items
    connection.execute("""
        CREATE TABLE IF NOT EXISTS todos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task TEXT NOT NULL,
            due_date TEXT NOT NULL,
            notes TEXT,
            completed INTEGER NOT NULL DEFAULT 0,
            completed_at TEXT,
            archived INTEGER NOT NULL DEFAULT 0,
            archived_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Patch up columns for any database file created before a given
    # feature existed (covers upgrading from an older copy of the app).
    _add_column_if_missing(connection, "production_stages", "started_at", "TEXT")
    _add_column_if_missing(connection, "production_stages", "completed_at", "TEXT")
    _add_column_if_missing(connection, "production_stages", "notes", "TEXT")
    _add_column_if_missing(connection, "production_stages", "assigned_staff_id", "INTEGER")

    _add_column_if_missing(connection, "todos", "completed_at", "TEXT")
    _add_column_if_missing(connection, "todos", "archived", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(connection, "todos", "archived_at", "TEXT")

    # due_time lets a reminder carry a specific time (e.g. a pickup/drop-off
    # appointment), not just a date. order_id/stage_id are optional links
    # back to the order and production stage a reminder was created from,
    # so a reminder added from a stage's "+ Reminder" button can show that
    # context and jump back to the order - both stay NULL for reminders
    # added from the general dashboard To-Do form.
    _add_column_if_missing(connection, "todos", "due_time", "TEXT")
    _add_column_if_missing(connection, "todos", "order_id", "INTEGER")
    _add_column_if_missing(connection, "todos", "stage_id", "INTEGER")

    # Which staff member a reminder is for, so a shared team can tell at a
    # glance who a pickup/drop-off/task belongs to. When a reminder is
    # created from a stage that already has someone assigned, this
    # defaults to that same person (see create_todo in app.py) but can
    # always be changed independently of the stage's own assignment.
    _add_column_if_missing(connection, "todos", "assigned_staff_id", "INTEGER")

    _add_column_if_missing(connection, "orders", "metal_type", "TEXT")
    _add_column_if_missing(connection, "orders", "metal_purity", "TEXT")
    _add_column_if_missing(connection, "orders", "gross_weight", "REAL")
    _add_column_if_missing(connection, "orders", "net_weight", "REAL")
    _add_column_if_missing(connection, "orders", "order_price", "REAL")
    _add_column_if_missing(connection, "orders", "deposit_paid", "REAL NOT NULL DEFAULT 0")
    _add_column_if_missing(connection, "orders", "product_id", "INTEGER")

    _add_column_if_missing(connection, "stone_transactions", "stone_type", "TEXT")
    _add_column_if_missing(connection, "stone_transactions", "shape", "TEXT")
    _add_column_if_missing(connection, "stone_transactions", "color", "TEXT")
    _add_column_if_missing(connection, "stone_transactions", "clarity", "TEXT")

    # google_credentials_json / google_sheet_id / google_sync_enabled /
    # google_last_synced_at / google_last_sync_error were added for a
    # service-account push-sync approach to Google Sheets that Google's
    # own "Secure by Default" org policy blocks for many accounts - kept
    # here (unused) only so upgrading a database that already has them
    # doesn't error; replaced by the data_link_token approach below.
    _add_column_if_missing(connection, "settings", "google_credentials_json", "TEXT")
    _add_column_if_missing(connection, "settings", "google_sheet_id", "TEXT")
    _add_column_if_missing(connection, "settings", "google_sync_enabled", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(connection, "settings", "google_last_synced_at", "TEXT")
    _add_column_if_missing(connection, "settings", "google_last_sync_error", "TEXT")

    _add_column_if_missing(connection, "settings", "data_link_token", "TEXT")

    # One-time backfill: carry any existing single-value stage notes into
    # the new stage_notes log, so nothing already written gets lost.
    legacy_notes = connection.execute(
        """
        SELECT id, notes FROM production_stages
        WHERE notes IS NOT NULL AND TRIM(notes) != ''
        AND NOT EXISTS (
            SELECT 1 FROM stage_notes WHERE stage_notes.stage_id = production_stages.id
        )
        """
    ).fetchall()

    for stage_row in legacy_notes:
        connection.execute(
            "INSERT INTO stage_notes (stage_id, note) VALUES (?, ?)",
            (stage_row["id"], stage_row["notes"])
        )

    connection.commit()
    connection.close()

    print(f"Database ready: {DATABASE}")


# Kept for backwards compatibility with anything that imported the old name.
setup_database = init_db


if __name__ == "__main__":
    init_db()
