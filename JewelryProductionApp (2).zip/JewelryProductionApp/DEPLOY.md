# Deploying Jewelry Production to PythonAnywhere

## Already live? Updating to a new version

You've already got this app running at `https://yourusername.pythonanywhere.com`.
To push a newer zip I've sent you over that same live app, without losing any
data:

1. Files tab → upload the new zip into your home directory
   (`/home/yourusername/`) - the same place your existing
   `JewelryProductionApp` folder already lives. Don't extract it yet.
2. Bash console:
   ```
   cd ~
   unzip -o new_zip_file_name.zip
   ```
   That's it - just one command. The zip's top-level folder is already named
   `JewelryProductionApp`, the same as your live folder, so unzipping
   straight into your home directory overwrites the code files in place
   (app.py, database_setup.py, templates/) without touching your existing
   `database/production.db` or `photos/` folder - neither of those is in the
   new zip, so unzip never goes near them.

   (Do **not** use `-d JewelryProductionApp_new` plus a manual `cp -r` step -
   that buries the new files inside an extra nested folder instead of
   actually replacing your code, and the site will look unchanged after you
   reload. If you've hit that before: `rm -rf ~/JewelryProductionApp_new`
   and check for a stray `~/JewelryProductionApp/JewelryProductionApp/`
   folder - `rm -rf` that too if it's there, it's just leftover clutter, not
   part of your real app.)
3. `cd JewelryProductionApp && pip install -r requirements.txt` (fast if
   nothing changed - just confirms everything's in place. An earlier
   version of this app briefly needed extra packages for Google Sheets -
   that's no longer the case, requirements.txt is back to just Flask and
   Werkzeug).
4. Web tab → **Reload**.
5. **One-time note if you're updating from a version before the in-app
   password/Settings page existed:** your login password used to live in
   the WSGI file's `APP_PASSWORD` line. The real password now moves into
   the database (so it can be changed from Settings inside the app) - the
   very first time the app starts after this update, it copies whatever
   `APP_PASSWORD` is currently set in your WSGI file into the database as
   your password, then ignores that line from then on. So log in with
   whatever password was in your WSGI file, then go to **Settings →
   Change Password** if you want to set a new one going forward.
6. **Google Sheets access is optional** - the app works exactly as before
   if you skip it. Go to **Settings → Live Data Links** inside the app
   once it's live: each report has its own always-current link, and
   pasting one into a Google Sheet with `=IMPORTDATA("...")` keeps that
   Sheet updated automatically - no Google account setup required.

---

This gets your app live at a URL like `https://yourname.pythonanywhere.com` that
you can open from your phone, laptop, or any browser — free, and it stays on
persistently (unlike most free hosts, which reset your files every time the
app goes to sleep).

**Heads up on storage:** the free plan gives you 512MB total for your database
and all uploaded photos/invoices. That's plenty to start. If you're uploading
a lot of product/stone photos and start running low, PythonAnywhere's paid
"Hacker" plan is $5/month for much more room — you can switch anytime without
losing anything.

## 1. Create your account

Go to [pythonanywhere.com](https://www.pythonanywhere.com) and sign up for the
free **Beginner** account.

## 2. Get the code onto PythonAnywhere

1. In PythonAnywhere, open a **Bash console** (Dashboard → Consoles → Bash).
2. Upload the app. Easiest way: from the **Files** tab, upload the zip file
   I gave you, then in the Bash console run:
   ```
   unzip JewelryProductionApp.zip
   cd JewelryProductionApp
   ```
   (No `-d` flag - the zip already contains a `JewelryProductionApp` folder,
   so unzipping straight into your home directory lands it in the right
   place. If `unzip` isn't found, run `pip install --user unzip` first, or
   use the Files tab's built-in "extract" option if it offers one.)

   Alternative: if you'd rather pull straight from GitHub, keep your repo
   public and instead run `git clone https://github.com/parasusadadiya/JewelryProductionApp.git`
   from the Bash console. You can then flip the repo back to private —
   future updates would need it public again for `git pull`, or you'd upload
   changed files by hand.

## 3. Create a virtual environment and install dependencies

Still in the Bash console:

```
mkvirtualenv --python=/usr/bin/python3.10 jewelry-env
pip install -r requirements.txt
```

(If `python3.10` isn't available, run `ls /usr/bin/python3.*` to see what
versions exist and use the newest one.)

## 4. Create the web app

1. Go to the **Web** tab → **Add a new web app**.
2. Choose **Manual configuration** (not the guided Flask option) and pick the
   same Python version you used for the virtualenv.
3. Under **Virtualenv**, enter the path PythonAnywhere shows for
   `jewelry-env` (usually `/home/yourusername/.virtualenvs/jewelry-env`).
4. Under **Code**, set the **Source code** directory to
   `/home/yourusername/JewelryProductionApp`.

## 5. Edit the WSGI configuration file

On the Web tab, click the WSGI configuration file link (something like
`/var/www/yourusername_pythonanywhere_com_wsgi.py`). Delete everything in it
and replace with:

```python
import sys
import os

path = '/home/yourusername/JewelryProductionApp'
if path not in sys.path:
    sys.path.insert(0, path)

# Set these BEFORE importing app, so it picks them up.
os.environ['APP_PASSWORD'] = 'choose-a-real-password-here'
os.environ['SECRET_KEY'] = 'paste-a-long-random-string-here'

from app import app as application
```

Replace `yourusername` with your actual PythonAnywhere username, pick a real
password for `APP_PASSWORD` (this is what you and your staff will type in to
log in), and generate a random `SECRET_KEY` by running this in a Bash
console and pasting the result:

```
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Save the file.

## 6. Reload and test

Back on the Web tab, click the big green **Reload** button. Then open
`https://yourusername.pythonanywhere.com` — you should see the login screen.
Log in with the password you set, create a test order, and confirm it shows
up on the dashboard.

## 7. Bookmark it on your phone

Open the same URL on your phone's browser and add it to your home screen
(Share → Add to Home Screen on iPhone, or the browser menu → Add to Home
Screen on Android) so it behaves like an app icon.

## Updating the app later

Whenever you make code changes:
- Re-upload the changed files (Files tab, or `git pull` if you cloned via
  git and the repo is still public), then click **Reload** on the Web tab.
- Your data (`database/production.db` and everything in `photos/`) is
  never touched by this — it lives outside your code.

## Backing up your data

Your orders/customers/photos live in `database/production.db` and the
`photos/` folder on the server, not in GitHub (they're intentionally
excluded via `.gitignore`). Periodically download both from the Files tab
and keep a copy somewhere safe (e.g. your computer or Google Drive) — that's
your only copy.

## Checking your storage usage

Dashboard → Files tab shows your disk usage at the top. If you're
approaching 512MB, that's your signal to either clean up old photos or
upgrade to the paid plan.
