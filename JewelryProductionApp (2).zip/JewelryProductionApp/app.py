from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    send_from_directory,
    session,
    flash,
    Response
)

from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

from pathlib import Path
from datetime import date, datetime, timedelta
import os
import sqlite3
import uuid
import csv
import io

import database_setup
import secrets


app = Flask(__name__)

# SECRET_KEY signs the login session cookie. Set a real value with the
# SECRET_KEY environment variable in production; this random fallback
# just means everyone gets logged out whenever the server restarts.
app.secret_key = os.environ.get("SECRET_KEY", os.urandom(24))

# The shared password used to log in to the app the very first time it
# runs. Set this with the APP_PASSWORD environment variable before
# deploying anywhere public. After the first run, the real password
# lives (hashed) in the database and is changed from Settings inside
# the app - this env var is only the initial seed.
APP_PASSWORD = os.environ.get("APP_PASSWORD", "changeme")


BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "database" / "production.db"
UPLOAD_FOLDER = BASE_DIR / "photos"

UPLOAD_FOLDER.mkdir(exist_ok=True)
(UPLOAD_FOLDER / "invoices").mkdir(exist_ok=True)
(UPLOAD_FOLDER / "stone_photos").mkdir(exist_ok=True)
(UPLOAD_FOLDER / "order_photos").mkdir(exist_ok=True)
(UPLOAD_FOLDER / "branding").mkdir(exist_ok=True)


STAGES = [
    "CAD",
    "Casting",
    "Stone",
    "Components",
    "Setting / Jewelry Work",
    "QC",
    "Finish"
]

ALLOWED_IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp"]

METAL_TYPES = ["Gold", "Silver", "Platinum", "Other"]

METAL_PURITIES = [
    "24K", "22K", "18K", "14K", "10K",
    "950 Platinum", "925 Silver", "Other"
]

STONE_SHAPES = [
    "Round", "Princess", "Oval", "Emerald", "Pear",
    "Marquise", "Cushion", "Radiant", "Asscher", "Other"
]

VENDOR_JOB_STATUSES = ["Sent", "In Progress", "Received"]


def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


# Make sure every table exists (and any older database file is patched
# up with newer columns) before the app starts handling requests.
database_setup.init_db()


def get_settings_row(connection):
    return connection.execute("SELECT * FROM settings WHERE id = 1").fetchone()


def ensure_password_seeded():
    """The first time the app ever runs, hash APP_PASSWORD into the
    settings table so login works out of the box. Every run after that,
    this is a no-op - the real password lives in the database and is
    changed from the Settings page, not by editing environment vars."""

    connection = get_connection()
    settings_row = get_settings_row(connection)

    if settings_row and not settings_row["app_password_hash"]:

        connection.execute(
            "UPDATE settings SET app_password_hash = ? WHERE id = 1",
            (generate_password_hash(APP_PASSWORD),)
        )
        connection.commit()

    connection.close()


ensure_password_seeded()


def parse_float(value):
    try:
        return float(value) if value not in (None, "") else None
    except ValueError:
        return None


def get_or_create_by_name(connection, table, name):
    """Look up a row by name in a small catalog table (products,
    components), creating it if it doesn't exist yet. table must be a
    trusted literal - never pass user input as the table name."""

    name = (name or "").strip()

    if not name:
        return None

    existing = connection.execute(
        f"SELECT id FROM {table} WHERE name = ?", (name,)
    ).fetchone()

    if existing:
        return existing["id"]

    cursor = connection.execute(
        f"INSERT INTO {table} (name) VALUES (?)", (name,)
    )

    return cursor.lastrowid


def get_workflow(order_type):

    if order_type == "Repair":

        return [
            "Stone",
            "Components",
            "Setting / Jewelry Work",
            "QC",
            "Finish"
        ]

    return list(STAGES)


def save_upload(file_storage, subfolder, prefix):
    """Save an uploaded image/file under photos/<subfolder>/ with a
    collision-proof name. Returns the public /photos/... path, or None
    if there was no file / it wasn't an allowed type."""

    if not file_storage or not file_storage.filename:
        return None

    extension = Path(file_storage.filename).suffix.lower()

    if extension not in ALLOWED_IMAGE_EXTENSIONS:
        return None

    filename = f"{prefix}_{uuid.uuid4().hex[:8]}{extension}"

    folder = UPLOAD_FOLDER / subfolder
    folder.mkdir(parents=True, exist_ok=True)

    file_storage.save(folder / filename)

    return f"/photos/{subfolder}/{filename}" if subfolder else f"/photos/{filename}"


def save_document(file_storage, subfolder, prefix):
    """Save an uploaded invoice (image or PDF). Returns the public path
    or None."""

    if not file_storage or not file_storage.filename:
        return None

    filename = secure_filename(file_storage.filename)

    if not filename:
        return None

    stored_name = f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{filename}"

    folder = UPLOAD_FOLDER / subfolder
    folder.mkdir(parents=True, exist_ok=True)

    file_storage.save(folder / stored_name)

    return f"/photos/{subfolder}/{stored_name}"


def is_image_path(path):
    """True if a stored /photos/... path looks like an image (vs. a PDF
    or other document) based on its file extension."""

    if not path:
        return False

    return Path(path).suffix.lower() in ALLOWED_IMAGE_EXTENSIONS


def delete_file_if_exists(public_path):
    """Best-effort delete of an uploaded file given its public /photos/...
    path. Never raises - a missing or already-deleted file is fine."""

    if not public_path:
        return

    try:
        real_path = BASE_DIR / public_path.lstrip("/")
        if real_path.is_file() and UPLOAD_FOLDER in real_path.parents:
            real_path.unlink()
    except OSError:
        pass


def csv_response(filename, headers, rows):
    """Build a Flask Response that downloads as an Excel/Sheets-friendly
    CSV file. rows is an iterable of lists/tuples matching headers."""

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(headers)
    writer.writerows(rows)

    # Leading BOM so Excel opens UTF-8 (e.g. names with accents) correctly.
    csv_text = "﻿" + buffer.getvalue()

    return Response(
        csv_text,
        mimetype="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


def parse_date_arg(value):
    """Parse a YYYY-MM-DD query-string date, or return None if blank/invalid."""

    if not value:
        return None
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError:
        return None


def compute_sidebar_counts(connection):

    counts = {"stages": STAGES}

    for stage in STAGES:

        result = connection.execute(
            """
            SELECT COUNT(*) AS count
            FROM production_stages
            WHERE stage_name = ?
            AND status != 'Completed'
            """,
            (stage,)
        ).fetchone()

        counts[stage] = result["count"]

    result = connection.execute(
        "SELECT COUNT(*) AS count FROM orders"
    ).fetchone()
    counts["New Orders"] = result["count"]

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM orders
        WHERE NOT EXISTS (
            SELECT 1 FROM production_stages
            WHERE production_stages.order_id = orders.id
            AND production_stages.status IN ('In Progress', 'Completed')
        )
        """
    ).fetchone()
    counts["Not Started Orders"] = result["count"]

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM orders
        WHERE EXISTS (
            SELECT 1 FROM production_stages
            WHERE production_stages.order_id = orders.id
            AND production_stages.status = 'In Progress'
        )
        """
    ).fetchone()
    counts["In Progress Orders"] = result["count"]

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM orders
        WHERE EXISTS (
            SELECT 1 FROM production_stages
            WHERE production_stages.order_id = orders.id
        )
        AND NOT EXISTS (
            SELECT 1 FROM production_stages
            WHERE production_stages.order_id = orders.id
            AND production_stages.status != 'Completed'
        )
        """
    ).fetchone()
    counts["Finished Orders"] = result["count"]

    today = date.today().isoformat()

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM orders
        WHERE due_date IS NOT NULL
        AND due_date != ''
        AND due_date < ?
        AND status != 'Completed'
        """,
        (today,)
    ).fetchone()
    counts["Overdue Orders"] = result["count"]

    result = connection.execute(
        "SELECT COUNT(*) AS count FROM customers"
    ).fetchone()
    counts["customer_count"] = result["count"]

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM production_stages
        WHERE assigned_staff_id IS NOT NULL
        AND status != 'Completed'
        """
    ).fetchone()
    counts["Assigned Work"] = result["count"]

    result = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM todos
        WHERE completed = 0 AND archived = 0
        """
    ).fetchone()
    counts["Pending Reminders"] = result["count"]

    return counts


@app.context_processor
def inject_sidebar_counts():

    if not session.get("logged_in"):
        return {}

    connection = get_connection()
    counts = compute_sidebar_counts(connection)
    connection.close()

    return {"sidebar_counts": counts}


@app.context_processor
def inject_app_settings():

    connection = get_connection()
    settings_row = get_settings_row(connection)
    connection.close()

    return {"app_settings": settings_row}


@app.route("/photos/<path:filename>")
def serve_photo(filename):

    return send_from_directory(
        UPLOAD_FOLDER,
        filename
    )


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        password = request.form.get("password", "")

        connection = get_connection()
        settings_row = get_settings_row(connection)
        connection.close()

        password_hash = settings_row["app_password_hash"] if settings_row else None

        if password_hash and check_password_hash(password_hash, password):

            session["logged_in"] = True

            next_page = request.form.get("next") or url_for("home")

            return redirect(next_page)

        flash("Incorrect password.")

    return render_template(
        "login.html",
        next=request.args.get("next", "")
    )


@app.route("/logout", methods=["POST"])
def logout():

    session.clear()

    return redirect(url_for("login"))


@app.before_request
def require_login():

    open_endpoints = {"login", "static", "serve_photo", "public_data_csv"}

    if request.endpoint in open_endpoints:
        return

    if not session.get("logged_in"):

        return redirect(
            url_for("login", next=request.path)
        )


# ---------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------

@app.route("/")
def home():

    connection = get_connection()

    counts = compute_sidebar_counts(connection)

    today = date.today().isoformat()
    soon = (date.today() + timedelta(days=3)).isoformat()

    overdue_orders = connection.execute(
        """
        SELECT orders.*, customers.name AS customer_name
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        WHERE orders.due_date IS NOT NULL
        AND orders.due_date != ''
        AND orders.due_date < ?
        AND orders.status != 'Completed'
        ORDER BY orders.due_date ASC
        LIMIT 8
        """,
        (today,)
    ).fetchall()

    due_soon_orders = connection.execute(
        """
        SELECT orders.*, customers.name AS customer_name
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        WHERE orders.due_date IS NOT NULL
        AND orders.due_date != ''
        AND orders.due_date >= ?
        AND orders.due_date <= ?
        AND orders.status != 'Completed'
        ORDER BY orders.due_date ASC
        LIMIT 8
        """,
        (today, soon)
    ).fetchall()

    unpaid_total = connection.execute(
        """
        SELECT COALESCE(SUM(order_price - deposit_paid), 0) AS total
        FROM orders
        WHERE order_price IS NOT NULL
        AND status != 'Completed'
        """
    ).fetchone()["total"]

    connection.close()

    return render_template(
        "dashboard.html",
        counts=counts,
        overdue_orders=overdue_orders,
        due_soon_orders=due_soon_orders,
        unpaid_total=unpaid_total,
        today=today
    )


# ---------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------

@app.route("/orders/new")
def new_order():

    connection = get_connection()

    customers = connection.execute(
        "SELECT * FROM customers ORDER BY name ASC"
    ).fetchall()

    products = connection.execute(
        "SELECT * FROM products WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    connection.close()

    return render_template(
        "order_form.html",
        order=None,
        customers=customers,
        products=products,
        metal_types=METAL_TYPES,
        metal_purities=METAL_PURITIES
    )


@app.route("/orders/create", methods=["POST"])
def create_order():

    customer_id = request.form.get("customer_id", "").strip()
    new_customer_name = request.form.get("new_customer_name", "").strip()

    order_type = request.form.get("order_type", "New")

    product_id_raw = request.form.get("product_id", "").strip()
    new_product_name = request.form.get("new_product_name", "").strip()
    product_number = request.form.get("product_number", "").strip()

    quantity = request.form.get("quantity", "1")
    due_date = request.form.get("due_date", "")
    notes = request.form.get("notes", "").strip()

    metal_type = request.form.get("metal_type", "").strip()
    metal_purity = request.form.get("metal_purity", "").strip()
    gross_weight = request.form.get("gross_weight", "").strip()
    net_weight = request.form.get("net_weight", "").strip()
    order_price = request.form.get("order_price", "").strip()
    deposit_paid = request.form.get("deposit_paid", "").strip()

    connection = get_connection()

    if customer_id:

        customer = connection.execute(
            "SELECT id FROM customers WHERE id = ?",
            (customer_id,)
        ).fetchone()

        if not customer:
            connection.close()
            return ("Selected customer not found", 400)

        customer_id = customer["id"]

    elif new_customer_name:

        existing = connection.execute(
            "SELECT id FROM customers WHERE name = ?",
            (new_customer_name,)
        ).fetchone()

        if existing:
            customer_id = existing["id"]
        else:
            cursor = connection.execute(
                "INSERT INTO customers (name) VALUES (?)",
                (new_customer_name,)
            )
            customer_id = cursor.lastrowid

    else:
        connection.close()
        return ("Please choose an existing customer or enter a new customer name", 400)

    if product_id_raw:
        product_id = int(product_id_raw)
    elif new_product_name:
        product_id = get_or_create_by_name(connection, "products", new_product_name)
    else:
        product_id = None

    try:
        quantity = int(quantity)
    except ValueError:
        quantity = 1

    gross_weight = parse_float(gross_weight)
    net_weight = parse_float(net_weight)
    order_price = parse_float(order_price)
    deposit_paid = parse_float(deposit_paid) or 0

    order_number = "J-" + uuid.uuid4().hex[:8].upper()

    # Cover photo (first uploaded photo, kept for quick thumbnails)
    photo_path = None
    photo_files = request.files.getlist("photos")

    saved_photo_paths = []

    for photo_file in photo_files:

        saved_path = save_upload(photo_file, "order_photos", order_number)

        if saved_path:
            saved_photo_paths.append(saved_path)

    if saved_photo_paths:
        photo_path = saved_photo_paths[0]

    cursor = connection.execute(
        """
        INSERT INTO orders (
            order_number, customer_id, order_type, product_id, product_number,
            quantity, order_date, due_date, photo_path, notes,
            metal_type, metal_purity, gross_weight, net_weight,
            order_price, deposit_paid, current_stage, status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            order_number, customer_id, order_type, product_id, product_number,
            quantity, date.today().isoformat(), due_date, photo_path, notes,
            metal_type or None, metal_purity or None, gross_weight, net_weight,
            order_price, deposit_paid, "Customer Order", "Pending"
        )
    )

    order_id = cursor.lastrowid

    for saved_path in saved_photo_paths:

        connection.execute(
            """
            INSERT INTO order_photos (order_id, photo_path)
            VALUES (?, ?)
            """,
            (order_id, saved_path)
        )

    if deposit_paid:

        connection.execute(
            """
            INSERT INTO payments (order_id, amount, payment_date, method, notes)
            VALUES (?, ?, ?, ?, ?)
            """,
            (order_id, deposit_paid, date.today().isoformat(), "Initial deposit", "")
        )

    workflow = get_workflow(order_type)

    for stage in workflow:

        connection.execute(
            """
            INSERT INTO production_stages (order_id, stage_name, status)
            VALUES (?, ?, ?)
            """,
            (order_id, stage, "Pending")
        )

    connection.commit()
    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders")
def orders():

    connection = get_connection()

    stage_filter = request.args.get("stage", "").strip()
    order_filter = request.args.get("filter", "").strip()
    search_query = request.args.get("q", "").strip()

    base_query = """
        SELECT orders.*, customers.name AS customer_name,
               products.name AS product_name
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        LEFT JOIN products ON products.id = orders.product_id
    """

    conditions = []
    params = []

    today = date.today().isoformat()

    if search_query:

        conditions.append(
            "(orders.order_number LIKE ? OR customers.name LIKE ? "
            "OR orders.product_number LIKE ? OR products.name LIKE ? "
            "OR customers.phone LIKE ?)"
        )
        like_term = f"%{search_query}%"
        params.extend([like_term, like_term, like_term, like_term, like_term])

    if stage_filter:

        conditions.append(
            """
            EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.stage_name = ?
                AND production_stages.status != 'Completed'
            )
            """
        )
        params.append(stage_filter)

    elif order_filter == "in_progress":

        conditions.append(
            """
            EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.status = 'In Progress'
            )
            """
        )

    elif order_filter == "not_started":

        conditions.append(
            """
            NOT EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.status IN ('In Progress', 'Completed')
            )
            """
        )

    elif order_filter == "finished":

        conditions.append(
            """
            EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
            )
            AND NOT EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.status != 'Completed'
            )
            """
        )

    elif order_filter == "overdue":

        conditions.append(
            "orders.due_date IS NOT NULL AND orders.due_date != '' "
            "AND orders.due_date < ? AND orders.status != 'Completed'"
        )
        params.append(today)

    if conditions:
        base_query += " WHERE " + " AND ".join(conditions)

    base_query += " ORDER BY orders.id DESC"

    order_rows = connection.execute(base_query, params).fetchall()

    connection.close()

    return render_template(
        "orders.html",
        orders=order_rows,
        search_query=search_query,
        stage_filter=stage_filter,
        order_filter=order_filter,
        today=today
    )


@app.route("/orders/<int:order_id>")
def order_details(order_id):

    connection = get_connection()

    order = connection.execute(
        """
        SELECT orders.*, customers.name AS customer_name,
               customers.phone AS customer_phone,
               products.name AS product_name
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        LEFT JOIN products ON products.id = orders.product_id
        WHERE orders.id = ?
        """,
        (order_id,)
    ).fetchone()

    if not order:
        connection.close()
        return ("Order not found", 404)

    stages = connection.execute(
        """
        SELECT production_stages.*, staff.name AS assigned_staff_name
        FROM production_stages
        LEFT JOIN staff ON staff.id = production_stages.assigned_staff_id
        WHERE production_stages.order_id = ?
        ORDER BY production_stages.id
        """,
        (order_id,)
    ).fetchall()

    stage_notes_rows = connection.execute(
        """
        SELECT stage_notes.*
        FROM stage_notes
        JOIN production_stages ON production_stages.id = stage_notes.stage_id
        WHERE production_stages.order_id = ?
        ORDER BY stage_notes.created_at ASC, stage_notes.id ASC
        """,
        (order_id,)
    ).fetchall()

    stage_notes_by_stage = {}

    for note_row in stage_notes_rows:
        stage_notes_by_stage.setdefault(note_row["stage_id"], []).append(note_row)

    stone_transactions = connection.execute(
        """
        SELECT * FROM stone_transactions
        WHERE order_id = ?
        ORDER BY id DESC
        """,
        (order_id,)
    ).fetchall()

    order_photos = connection.execute(
        """
        SELECT * FROM order_photos
        WHERE order_id = ?
        ORDER BY id DESC
        """,
        (order_id,)
    ).fetchall()

    payments = connection.execute(
        """
        SELECT * FROM payments
        WHERE order_id = ?
        ORDER BY payment_date DESC, id DESC
        """,
        (order_id,)
    ).fetchall()

    order_components = connection.execute(
        """
        SELECT order_components.*, components.name AS component_name
        FROM order_components
        LEFT JOIN components ON components.id = order_components.component_id
        WHERE order_components.order_id = ?
        ORDER BY order_components.id DESC
        """,
        (order_id,)
    ).fetchall()

    vendor_jobs = connection.execute(
        """
        SELECT * FROM vendor_jobs
        WHERE order_id = ?
        ORDER BY id DESC
        """,
        (order_id,)
    ).fetchall()

    staff_members = connection.execute(
        "SELECT * FROM staff WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    components_catalog = connection.execute(
        "SELECT * FROM components WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    connection.close()

    balance_due = None
    payment_status = "No Price Set"

    if order["order_price"] is not None:

        balance_due = round(order["order_price"] - order["deposit_paid"], 2)

        if balance_due <= 0:
            payment_status = "Paid"
        elif order["deposit_paid"] > 0:
            payment_status = "Partial"
        else:
            payment_status = "Unpaid"

    return render_template(
        "order_details.html",
        order=order,
        stages=stages,
        stage_notes_by_stage=stage_notes_by_stage,
        stone_transactions=stone_transactions,
        order_photos=order_photos,
        payments=payments,
        order_components=order_components,
        vendor_jobs=vendor_jobs,
        staff_members=staff_members,
        components_catalog=components_catalog,
        stone_shapes=STONE_SHAPES,
        vendor_job_statuses=VENDOR_JOB_STATUSES,
        balance_due=balance_due,
        payment_status=payment_status,
        today=date.today().isoformat()
    )


@app.route("/orders/<int:order_id>/delete", methods=["POST"])
def delete_order(order_id):
    """Permanently delete an order and everything logged against it
    (photos, payments, stages/notes, components, vendor jobs, stone
    transactions) - and the uploaded files on disk for it. Meant for
    cleaning up test/duplicate orders; this cannot be undone."""

    connection = get_connection()

    order = connection.execute(
        "SELECT * FROM orders WHERE id = ?", (order_id,)
    ).fetchone()

    if not order:
        connection.close()
        flash("That order no longer exists.")
        return redirect(url_for("orders"))

    order_photo_rows = connection.execute(
        "SELECT photo_path FROM order_photos WHERE order_id = ?", (order_id,)
    ).fetchall()

    stone_file_rows = connection.execute(
        "SELECT invoice_path, photo_path FROM stone_transactions WHERE order_id = ?",
        (order_id,)
    ).fetchall()

    stage_ids = [
        row["id"] for row in connection.execute(
            "SELECT id FROM production_stages WHERE order_id = ?", (order_id,)
        ).fetchall()
    ]

    if stage_ids:
        placeholders = ",".join("?" for _ in stage_ids)
        connection.execute(
            f"DELETE FROM stage_notes WHERE stage_id IN ({placeholders})",
            stage_ids
        )

    connection.execute("DELETE FROM production_stages WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM order_photos WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM payments WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM order_components WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM vendor_jobs WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM stone_transactions WHERE order_id = ?", (order_id,))
    connection.execute("DELETE FROM orders WHERE id = ?", (order_id,))

    connection.commit()
    connection.close()

    # Clean up uploaded files on disk (best-effort, after the DB commit
    # so a file-cleanup hiccup never blocks the actual deletion).
    delete_file_if_exists(order["photo_path"])
    for row in order_photo_rows:
        delete_file_if_exists(row["photo_path"])
    for row in stone_file_rows:
        delete_file_if_exists(row["invoice_path"])
        delete_file_if_exists(row["photo_path"])

    flash(f"Order {order['order_number']} was deleted.")
    return redirect(url_for("orders"))


@app.route("/orders/<int:order_id>/edit", methods=["GET", "POST"])
def edit_order(order_id):

    connection = get_connection()

    order = connection.execute(
        "SELECT * FROM orders WHERE id = ?",
        (order_id,)
    ).fetchone()

    if not order:
        connection.close()
        return ("Order not found", 404)

    if request.method == "POST":

        customer_id = request.form.get("customer_id", "").strip()

        product_id_raw = request.form.get("product_id", "").strip()
        new_product_name = request.form.get("new_product_name", "").strip()
        product_number = request.form.get("product_number", "").strip()

        quantity = request.form.get("quantity", "1")
        due_date = request.form.get("due_date", "")
        notes = request.form.get("notes", "").strip()

        metal_type = request.form.get("metal_type", "").strip()
        metal_purity = request.form.get("metal_purity", "").strip()
        gross_weight = request.form.get("gross_weight", "").strip()
        net_weight = request.form.get("net_weight", "").strip()
        order_price = request.form.get("order_price", "").strip()

        if product_id_raw:
            product_id = int(product_id_raw)
        elif new_product_name:
            product_id = get_or_create_by_name(connection, "products", new_product_name)
        else:
            product_id = order["product_id"]

        try:
            quantity = int(quantity)
        except ValueError:
            quantity = 1

        connection.execute(
            """
            UPDATE orders
            SET customer_id = ?, product_id = ?, product_number = ?, quantity = ?,
                due_date = ?, notes = ?, metal_type = ?, metal_purity = ?,
                gross_weight = ?, net_weight = ?, order_price = ?
            WHERE id = ?
            """,
            (
                customer_id or order["customer_id"], product_id, product_number, quantity,
                due_date, notes, metal_type or None, metal_purity or None,
                parse_float(gross_weight), parse_float(net_weight),
                parse_float(order_price), order_id
            )
        )

        connection.commit()
        connection.close()

        return redirect(url_for("order_details", order_id=order_id))

    customers = connection.execute(
        "SELECT * FROM customers ORDER BY name ASC"
    ).fetchall()

    products = connection.execute(
        "SELECT * FROM products WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    connection.close()

    return render_template(
        "order_form.html",
        order=order,
        customers=customers,
        products=products,
        metal_types=METAL_TYPES,
        metal_purities=METAL_PURITIES
    )


@app.route("/orders/<int:order_id>/photos/add", methods=["POST"])
def add_order_photo(order_id):

    connection = get_connection()

    order = connection.execute(
        "SELECT order_number FROM orders WHERE id = ?",
        (order_id,)
    ).fetchone()

    if not order:
        connection.close()
        return ("Order not found", 404)

    caption = request.form.get("caption", "").strip()
    photo_files = request.files.getlist("photos")

    added_any = False

    for photo_file in photo_files:

        saved_path = save_upload(photo_file, "order_photos", order["order_number"])

        if saved_path:

            connection.execute(
                """
                INSERT INTO order_photos (order_id, photo_path, caption)
                VALUES (?, ?, ?)
                """,
                (order_id, saved_path, caption)
            )
            added_any = True

    if added_any:

        cover = connection.execute(
            "SELECT photo_path FROM orders WHERE id = ?",
            (order_id,)
        ).fetchone()

        if not cover["photo_path"]:

            first_photo = connection.execute(
                """
                SELECT photo_path FROM order_photos
                WHERE order_id = ? ORDER BY id ASC LIMIT 1
                """,
                (order_id,)
            ).fetchone()

            if first_photo:
                connection.execute(
                    "UPDATE orders SET photo_path = ? WHERE id = ?",
                    (first_photo["photo_path"], order_id)
                )

    connection.commit()
    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders/<int:order_id>/photos/<int:photo_id>/delete", methods=["POST"])
def delete_order_photo(order_id, photo_id):

    connection = get_connection()

    photo = connection.execute(
        "SELECT * FROM order_photos WHERE id = ? AND order_id = ?",
        (photo_id, order_id)
    ).fetchone()

    if not photo:
        connection.close()
        flash("That photo no longer exists.")
        return redirect(url_for("order_details", order_id=order_id))

    order = connection.execute(
        "SELECT photo_path FROM orders WHERE id = ?", (order_id,)
    ).fetchone()

    connection.execute("DELETE FROM order_photos WHERE id = ?", (photo_id,))

    # If the deleted photo was the order's cover photo, promote the next
    # remaining gallery photo (if any) to cover, or clear it to none.
    if order and order["photo_path"] == photo["photo_path"]:

        next_photo = connection.execute(
            """
            SELECT photo_path FROM order_photos
            WHERE order_id = ? ORDER BY id ASC LIMIT 1
            """,
            (order_id,)
        ).fetchone()

        connection.execute(
            "UPDATE orders SET photo_path = ? WHERE id = ?",
            (next_photo["photo_path"] if next_photo else None, order_id)
        )

    connection.commit()
    connection.close()

    delete_file_if_exists(photo["photo_path"])

    flash("Photo deleted.")
    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders/<int:order_id>/payments/add", methods=["POST"])
def add_payment(order_id):

    amount = request.form.get("amount", "").strip()
    payment_date = request.form.get("payment_date", "").strip() or date.today().isoformat()
    method = request.form.get("method", "").strip()
    notes = request.form.get("notes", "").strip()

    amount = parse_float(amount)

    if amount:

        connection = get_connection()

        connection.execute(
            """
            INSERT INTO payments (order_id, amount, payment_date, method, notes)
            VALUES (?, ?, ?, ?, ?)
            """,
            (order_id, amount, payment_date, method, notes)
        )

        connection.execute(
            """
            UPDATE orders
            SET deposit_paid = deposit_paid + ?
            WHERE id = ?
            """,
            (amount, order_id)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route(
    "/orders/<int:order_id>/stones/<int:transaction_id>/invoice",
    methods=["POST"]
)
def attach_stone_invoice(order_id, transaction_id):

    invoice_file = request.files.get("invoice")
    invoice_path = save_document(invoice_file, "invoices", "invoice")

    if invoice_path:

        connection = get_connection()

        connection.execute(
            """
            UPDATE stone_transactions
            SET invoice_path = ?
            WHERE id = ? AND order_id = ?
            """,
            (invoice_path, transaction_id, order_id)
        )

        connection.commit()
        connection.close()

    return redirect(f"/orders/{order_id}")


@app.route(
    "/orders/<int:order_id>/stones/create",
    methods=["POST"]
)
def create_stone_transaction(order_id):

    transaction_type = request.form.get("transaction_type", "").strip()
    stone_type = request.form.get("stone_type", "").strip()
    shape = request.form.get("shape", "").strip()
    color = request.form.get("color", "").strip()
    clarity = request.form.get("clarity", "").strip()
    stone_description = request.form.get("stone_description", "").strip()
    vendor_name = request.form.get("vendor_name", "").strip()
    quantity = request.form.get("quantity", "").strip()
    carat = request.form.get("carat", "").strip()
    pickup_date = request.form.get("pickup_date", "").strip()
    transaction_date = request.form.get("transaction_date", "").strip()
    reason = request.form.get("reason", "").strip()
    notes = request.form.get("notes", "").strip()

    invoice_path = save_document(request.files.get("invoice"), "invoices", "invoice")
    photo_path = save_upload(request.files.get("stone_photo"), "stone_photos", "stone")

    connection = get_connection()

    connection.execute(
        """
        INSERT INTO stone_transactions (
            order_id, transaction_type, stone_type, shape, color, clarity,
            stone_description, vendor_name, quantity, carat,
            transaction_date, pickup_date, invoice_path, photo_path,
            reason, notes, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """,
        (
            order_id, transaction_type, stone_type or None, shape or None,
            color or None, clarity or None, stone_description, vendor_name,
            parse_float(quantity), parse_float(carat),
            transaction_date or datetime.now().strftime("%Y-%m-%d"),
            pickup_date, invoice_path, photo_path, reason, notes
        )
    )

    connection.commit()
    connection.close()

    return redirect(f"/orders/{order_id}")


@app.route(
    "/orders/<int:order_id>/stages/<int:stage_id>/start",
    methods=["POST"]
)
def start_stage(order_id, stage_id):

    connection = get_connection()

    stage = connection.execute(
        "SELECT * FROM production_stages WHERE id = ? AND order_id = ?",
        (stage_id, order_id)
    ).fetchone()

    if not stage:
        connection.close()
        return ("Production stage not found", 404)

    now = datetime.now().isoformat(timespec="seconds")

    connection.execute(
        """
        UPDATE production_stages
        SET status = 'In Progress', started_at = ?
        WHERE id = ?
        """,
        (now, stage_id)
    )

    connection.execute(
        """
        UPDATE orders
        SET current_stage = ?, status = 'In Progress'
        WHERE id = ?
        """,
        (stage["stage_name"], order_id)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route(
    "/orders/<int:order_id>/stages/<int:stage_id>/assign",
    methods=["POST"]
)
def assign_stage(order_id, stage_id):

    assigned_staff_id = request.form.get("assigned_staff_id", "").strip()

    connection = get_connection()

    connection.execute(
        """
        UPDATE production_stages
        SET assigned_staff_id = ?
        WHERE id = ? AND order_id = ?
        """,
        (assigned_staff_id or None, stage_id, order_id)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route(
    "/orders/<int:order_id>/stages/<int:stage_id>/complete",
    methods=["POST"]
)
def complete_stage(order_id, stage_id):

    connection = get_connection()

    stage = connection.execute(
        "SELECT * FROM production_stages WHERE id = ? AND order_id = ?",
        (stage_id, order_id)
    ).fetchone()

    if not stage:
        connection.close()
        return ("Production stage not found", 404)

    now = datetime.now().isoformat(timespec="seconds")

    connection.execute(
        """
        UPDATE production_stages
        SET status = 'Completed', completed_at = ?
        WHERE id = ?
        """,
        (now, stage_id)
    )

    next_stage = connection.execute(
        """
        SELECT * FROM production_stages
        WHERE order_id = ? AND status != 'Completed'
        ORDER BY id LIMIT 1
        """,
        (order_id,)
    ).fetchone()

    if next_stage:

        connection.execute(
            """
            UPDATE orders
            SET current_stage = ?, status = 'In Progress'
            WHERE id = ?
            """,
            (next_stage["stage_name"], order_id)
        )

    else:

        connection.execute(
            """
            UPDATE orders
            SET current_stage = 'Finish', status = 'Completed'
            WHERE id = ?
            """,
            (order_id,)
        )

    connection.commit()
    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route(
    "/orders/<int:order_id>/stages/<int:stage_id>/notes/add",
    methods=["POST"]
)
def add_stage_note(order_id, stage_id):

    note = request.form.get("note", "").strip()

    if note:

        connection = get_connection()

        connection.execute(
            "INSERT INTO stage_notes (stage_id, note) VALUES (?, ?)",
            (stage_id, note)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route(
    "/orders/<int:order_id>/stages/<int:stage_id>/notes/<int:note_id>/edit",
    methods=["POST"]
)
def edit_stage_note(order_id, stage_id, note_id):

    note = request.form.get("note", "").strip()

    if note:

        connection = get_connection()

        connection.execute(
            """
            UPDATE stage_notes
            SET note = ?, updated_at = datetime('now')
            WHERE id = ? AND stage_id = ?
            """,
            (note, note_id, stage_id)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders/<int:order_id>/components/add", methods=["POST"])
def add_order_component(order_id):

    component_id_raw = request.form.get("component_id", "").strip()
    new_component_name = request.form.get("new_component_name", "").strip()
    quantity = request.form.get("quantity", "").strip()
    notes = request.form.get("notes", "").strip()

    connection = get_connection()

    if component_id_raw:
        component_id = int(component_id_raw)
    elif new_component_name:
        component_id = get_or_create_by_name(connection, "components", new_component_name)
    else:
        component_id = None

    if component_id:

        connection.execute(
            """
            INSERT INTO order_components (order_id, component_id, quantity, notes)
            VALUES (?, ?, ?, ?)
            """,
            (order_id, component_id, parse_float(quantity), notes)
        )

        connection.commit()

    connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders/<int:order_id>/vendor-jobs/add", methods=["POST"])
def add_vendor_job(order_id):

    vendor_name = request.form.get("vendor_name", "").strip()
    work_description = request.form.get("work_description", "").strip()
    status = request.form.get("status", "Sent").strip() or "Sent"
    sent_date = request.form.get("sent_date", "").strip() or date.today().isoformat()
    notes = request.form.get("notes", "").strip()

    if vendor_name:

        connection = get_connection()

        received_date = date.today().isoformat() if status == "Received" else None

        connection.execute(
            """
            INSERT INTO vendor_jobs (
                order_id, vendor_name, work_description, status,
                sent_date, received_date, notes
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (order_id, vendor_name, work_description, status, sent_date, received_date, notes)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("order_details", order_id=order_id))


@app.route("/orders/<int:order_id>/vendor-jobs/<int:job_id>/status", methods=["POST"])
def update_vendor_job_status(order_id, job_id):

    status = request.form.get("status", "").strip()

    if status:

        connection = get_connection()

        if status == "Received":

            connection.execute(
                """
                UPDATE vendor_jobs
                SET status = ?, received_date = COALESCE(received_date, ?)
                WHERE id = ? AND order_id = ?
                """,
                (status, date.today().isoformat(), job_id, order_id)
            )

        else:

            connection.execute(
                "UPDATE vendor_jobs SET status = ? WHERE id = ? AND order_id = ?",
                (status, job_id, order_id)
            )

        connection.commit()
        connection.close()

    return redirect(url_for("order_details", order_id=order_id))


# ---------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------

@app.route("/customers")
def customers():

    connection = get_connection()

    search_query = request.args.get("q", "").strip()

    query = """
        SELECT customers.*,
               COUNT(orders.id) AS order_count,
               MAX(orders.order_date) AS last_order_date
        FROM customers
        LEFT JOIN orders ON orders.customer_id = customers.id
    """

    params = []

    if search_query:

        query += " WHERE customers.name LIKE ? OR customers.phone LIKE ? OR customers.email LIKE ?"
        like_term = f"%{search_query}%"
        params.extend([like_term, like_term, like_term])

    query += " GROUP BY customers.id ORDER BY customers.name ASC"

    customer_rows = connection.execute(query, params).fetchall()

    connection.close()

    return render_template(
        "customers.html",
        customers=customer_rows,
        search_query=search_query
    )


@app.route("/customers/new", methods=["GET", "POST"])
def new_customer():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        notes = request.form.get("notes", "").strip()

        if not name:
            flash("Customer name is required.")
            return render_template("customer_form.html", customer=None)

        connection = get_connection()

        cursor = connection.execute(
            """
            INSERT INTO customers (name, phone, email, notes)
            VALUES (?, ?, ?, ?)
            """,
            (name, phone, email, notes)
        )

        customer_id = cursor.lastrowid

        connection.commit()
        connection.close()

        return redirect(url_for("customer_details", customer_id=customer_id))

    return render_template("customer_form.html", customer=None)


@app.route("/customers/<int:customer_id>")
def customer_details(customer_id):

    connection = get_connection()

    customer = connection.execute(
        "SELECT * FROM customers WHERE id = ?",
        (customer_id,)
    ).fetchone()

    if not customer:
        connection.close()
        return ("Customer not found", 404)

    customer_orders = connection.execute(
        """
        SELECT * FROM orders
        WHERE customer_id = ?
        ORDER BY id DESC
        """,
        (customer_id,)
    ).fetchall()

    connection.close()

    return render_template(
        "customer_details.html",
        customer=customer,
        orders=customer_orders,
        today=date.today().isoformat()
    )


@app.route("/customers/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):

    connection = get_connection()

    customer = connection.execute(
        "SELECT * FROM customers WHERE id = ?",
        (customer_id,)
    ).fetchone()

    if not customer:
        connection.close()
        return ("Customer not found", 404)

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        notes = request.form.get("notes", "").strip()

        if not name:
            connection.close()
            flash("Customer name is required.")
            return render_template("customer_form.html", customer=customer)

        connection.execute(
            """
            UPDATE customers
            SET name = ?, phone = ?, email = ?, notes = ?
            WHERE id = ?
            """,
            (name, phone, email, notes, customer_id)
        )

        connection.commit()
        connection.close()

        return redirect(url_for("customer_details", customer_id=customer_id))

    connection.close()

    return render_template("customer_form.html", customer=customer)


# ---------------------------------------------------------------------
# Settings (business info, password, staff, products, components)
# ---------------------------------------------------------------------

@app.route("/settings")
def settings():

    connection = get_connection()

    settings_row = get_settings_row(connection)

    staff_members = connection.execute(
        "SELECT * FROM staff ORDER BY active DESC, name ASC"
    ).fetchall()

    products = connection.execute(
        "SELECT * FROM products ORDER BY active DESC, name ASC"
    ).fetchall()

    components_list = connection.execute(
        "SELECT * FROM components ORDER BY active DESC, name ASC"
    ).fetchall()

    data_link_token = get_or_create_data_link_token(connection)

    connection.close()

    return render_template(
        "settings.html",
        settings=settings_row,
        staff_members=staff_members,
        products=products,
        components=components_list,
        data_link_token=data_link_token,
        data_link_reports=DATA_LINK_REPORTS
    )


@app.route("/settings/business", methods=["POST"])
def update_business_settings():

    business_name = request.form.get("business_name", "").strip()
    logo_file = request.files.get("logo")

    saved_logo = save_upload(logo_file, "branding", "logo")

    connection = get_connection()

    if saved_logo:

        connection.execute(
            """
            UPDATE settings
            SET business_name = ?, logo_path = ?, updated_at = datetime('now')
            WHERE id = 1
            """,
            (business_name, saved_logo)
        )

    else:

        connection.execute(
            """
            UPDATE settings
            SET business_name = ?, updated_at = datetime('now')
            WHERE id = 1
            """,
            (business_name,)
        )

    connection.commit()
    connection.close()

    return redirect(url_for("settings"))


@app.route("/settings/password", methods=["POST"])
def change_password():

    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")

    connection = get_connection()
    settings_row = get_settings_row(connection)

    stored_hash = settings_row["app_password_hash"] if settings_row else None

    if not stored_hash or not check_password_hash(stored_hash, current_password):

        flash("Current password is incorrect.")

    elif not new_password or new_password != confirm_password:

        flash("New passwords don't match.")

    else:

        connection.execute(
            """
            UPDATE settings
            SET app_password_hash = ?, updated_at = datetime('now')
            WHERE id = 1
            """,
            (generate_password_hash(new_password),)
        )

        connection.commit()

        flash("Password updated.")

    connection.close()

    return redirect(url_for("settings"))


@app.route("/settings/data-links/regenerate", methods=["POST"])
def regenerate_data_link_token():

    connection = get_connection()

    connection.execute(
        """
        UPDATE settings
        SET data_link_token = ?, updated_at = datetime('now')
        WHERE id = 1
        """,
        (secrets.token_urlsafe(24),)
    )
    connection.commit()
    connection.close()

    flash("Live data links regenerated - any links pasted into a Sheet before now have stopped working.")
    return redirect(url_for("settings"))


@app.route("/products/create", methods=["POST"])
def create_product():

    name = request.form.get("name", "").strip()

    if name:

        connection = get_connection()

        connection.execute(
            "INSERT OR IGNORE INTO products (name) VALUES (?)",
            (name,)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("settings"))


@app.route("/products/<int:product_id>/toggle", methods=["POST"])
def toggle_product(product_id):

    connection = get_connection()

    connection.execute(
        "UPDATE products SET active = 1 - active WHERE id = ?",
        (product_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("settings"))


@app.route("/components/create", methods=["POST"])
def create_component():

    name = request.form.get("name", "").strip()

    if name:

        connection = get_connection()

        connection.execute(
            "INSERT OR IGNORE INTO components (name) VALUES (?)",
            (name,)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("settings"))


@app.route("/components/<int:component_id>/toggle", methods=["POST"])
def toggle_component(component_id):

    connection = get_connection()

    connection.execute(
        "UPDATE components SET active = 1 - active WHERE id = ?",
        (component_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("settings"))


@app.route("/staff")
def staff():
    # Staff management now lives on the Settings page.
    return redirect(url_for("settings"))


@app.route("/staff/create", methods=["POST"])
def create_staff():

    name = request.form.get("name", "").strip()
    role = request.form.get("role", "").strip()

    if name:

        connection = get_connection()

        connection.execute(
            "INSERT INTO staff (name, role) VALUES (?, ?)",
            (name, role)
        )

        connection.commit()
        connection.close()

    return redirect(url_for("settings"))


@app.route("/staff/<int:staff_id>/toggle", methods=["POST"])
def toggle_staff(staff_id):

    connection = get_connection()

    connection.execute(
        "UPDATE staff SET active = 1 - active WHERE id = ?",
        (staff_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("settings"))


# ---------------------------------------------------------------------
# To-Dos / Reminders
# ---------------------------------------------------------------------

@app.route("/reminders")
def reminders():
    """The dedicated Reminders / To-Do page - everything to do with
    reminders lives here now (it used to be a section on the
    dashboard). Each reminder can optionally be tied back to an order/
    stage it was created from, and can optionally be assigned to a
    staff member so a shared team can tell at a glance who it's for."""

    connection = get_connection()

    # Automatically archive completed To-Do items after 4 days.
    connection.execute(
        """
        UPDATE todos
        SET archived = 1, archived_at = datetime('now')
        WHERE completed = 1
        AND archived = 0
        AND completed_at IS NOT NULL
        AND completed_at <= datetime('now', '-4 days')
        """
    )
    connection.commit()

    staff_members = connection.execute(
        "SELECT * FROM staff WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    todos = connection.execute(
        """
        SELECT todos.id, todos.task, todos.due_date, todos.due_time, todos.notes,
               todos.order_id, orders.order_number,
               todos.assigned_staff_id, staff.name AS assigned_staff_name
        FROM todos
        LEFT JOIN orders ON orders.id = todos.order_id
        LEFT JOIN staff ON staff.id = todos.assigned_staff_id
        WHERE todos.completed = 0 AND todos.archived = 0
        ORDER BY todos.due_date ASC, todos.due_time ASC, todos.id ASC
        """
    ).fetchall()

    completed_todos = connection.execute(
        """
        SELECT todos.id, todos.task, todos.due_date, todos.due_time, todos.notes,
               todos.completed_at, todos.order_id, orders.order_number,
               todos.assigned_staff_id, staff.name AS assigned_staff_name
        FROM todos
        LEFT JOIN orders ON orders.id = todos.order_id
        LEFT JOIN staff ON staff.id = todos.assigned_staff_id
        WHERE todos.completed = 1 AND todos.archived = 0
        ORDER BY todos.completed_at DESC, todos.id DESC
        """
    ).fetchall()

    connection.close()

    return render_template(
        "reminders.html",
        staff_members=staff_members,
        todos=todos,
        completed_todos=completed_todos
    )


@app.route("/todos/create", methods=["POST"])
def create_todo():

    task = request.form.get("task", "").strip()
    due_date = request.form.get("due_date", "").strip()
    due_time = request.form.get("due_time", "").strip()
    notes = request.form.get("notes", "").strip()
    order_id = request.form.get("order_id", "").strip()
    stage_id = request.form.get("stage_id", "").strip()
    assigned_staff_id = request.form.get("assigned_staff_id", "").strip()

    if not task or not due_date:
        if order_id:
            return redirect(url_for("order_details", order_id=order_id))
        return redirect(url_for("reminders"))

    connection = get_connection()

    # If this reminder was created from a stage and no staff was picked
    # explicitly, default it to whoever that stage is currently assigned
    # to - so the reminder reflects the stage's own assignment.
    if not assigned_staff_id and stage_id:
        stage_row = connection.execute(
            "SELECT assigned_staff_id FROM production_stages WHERE id = ?",
            (stage_id,)
        ).fetchone()
        if stage_row and stage_row["assigned_staff_id"]:
            assigned_staff_id = str(stage_row["assigned_staff_id"])

    connection.execute(
        """
        INSERT INTO todos (task, due_date, due_time, notes, order_id, stage_id, assigned_staff_id, completed, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0, datetime('now'))
        """,
        (task, due_date, due_time or None, notes, order_id or None, stage_id or None, assigned_staff_id or None)
    )

    connection.commit()
    connection.close()

    if order_id:
        return redirect(url_for("order_details", order_id=order_id))

    return redirect(url_for("reminders"))


@app.route("/todos/<int:todo_id>/complete", methods=["POST"])
def complete_todo(todo_id):

    connection = get_connection()

    connection.execute(
        """
        UPDATE todos
        SET completed = 1, completed_at = datetime('now')
        WHERE id = ?
        """,
        (todo_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("reminders"))


@app.route("/todos/<int:todo_id>/pending", methods=["POST"])
def pending_todo(todo_id):

    connection = get_connection()

    connection.execute(
        """
        UPDATE todos
        SET completed = 0, completed_at = NULL
        WHERE id = ?
        """,
        (todo_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("reminders"))


@app.route("/todos/<int:todo_id>/archive", methods=["POST"])
def archive_todo(todo_id):

    connection = get_connection()

    connection.execute(
        """
        UPDATE todos
        SET archived = 1, archived_at = datetime('now')
        WHERE id = ? AND completed = 1 AND archived = 0
        """,
        (todo_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("reminders"))


@app.route("/todos/<int:todo_id>/edit", methods=["POST"])
def edit_todo(todo_id):

    task = request.form.get("task", "").strip()
    due_date = request.form.get("due_date", "").strip()
    due_time = request.form.get("due_time", "").strip()
    notes = request.form.get("notes", "").strip()
    assigned_staff_id = request.form.get("assigned_staff_id", "").strip()

    if not task or not due_date:
        return redirect(url_for("reminders"))

    connection = get_connection()

    connection.execute(
        """
        UPDATE todos
        SET task = ?, due_date = ?, due_time = ?, notes = ?, assigned_staff_id = ?
        WHERE id = ? AND completed = 0
        """,
        (task, due_date, due_time or None, notes, assigned_staff_id or None, todo_id)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("reminders"))


@app.route("/todos/archived")
def archived_todos():

    connection = get_connection()

    archived_rows = connection.execute(
        """
        SELECT todos.id, todos.task, todos.due_date, todos.due_time, todos.notes,
               todos.completed_at, todos.archived_at, todos.order_id, orders.order_number,
               todos.assigned_staff_id, staff.name AS assigned_staff_name
        FROM todos
        LEFT JOIN orders ON orders.id = todos.order_id
        LEFT JOIN staff ON staff.id = todos.assigned_staff_id
        WHERE todos.archived = 1
        ORDER BY todos.archived_at DESC, todos.id DESC
        """
    ).fetchall()

    connection.close()

    return render_template("archived_todos.html", archived_todos=archived_rows)


# ---------------------------------------------------------------------
# Assign Work
# ---------------------------------------------------------------------

@app.route("/assign-work")
def assign_work():
    """A staff-centric view of production work: every non-completed stage
    that currently has (or needs) a staff member assigned. It's a live
    read of production_stages.assigned_staff_id, the same column the
    "Assign" control on each order's stage writes to - so any assignment
    made from an order page shows up here automatically, no separate
    bookkeeping required."""

    staff_filter = request.args.get("staff", "").strip()

    connection = get_connection()

    staff_members = connection.execute(
        "SELECT * FROM staff WHERE active = 1 ORDER BY name ASC"
    ).fetchall()

    base_query = """
        SELECT production_stages.*, orders.order_number, orders.due_date AS order_due_date,
               orders.status AS order_status, customers.name AS customer_name,
               products.name AS product_name, staff.name AS assigned_staff_name
        FROM production_stages
        JOIN orders ON orders.id = production_stages.order_id
        JOIN customers ON customers.id = orders.customer_id
        LEFT JOIN products ON products.id = orders.product_id
        LEFT JOIN staff ON staff.id = production_stages.assigned_staff_id
        WHERE production_stages.status != 'Completed'
    """
    params = []

    if staff_filter == "unassigned":
        base_query += " AND production_stages.assigned_staff_id IS NULL"
    elif staff_filter and staff_filter.isdigit():
        base_query += " AND production_stages.assigned_staff_id = ?"
        params.append(int(staff_filter))
    else:
        base_query += " AND production_stages.assigned_staff_id IS NOT NULL"

    base_query += """
        ORDER BY staff.name ASC, orders.due_date ASC, production_stages.id ASC
    """

    assignments = connection.execute(base_query, params).fetchall()

    counts_by_staff = {}
    for row in connection.execute(
        """
        SELECT assigned_staff_id, COUNT(*) AS count
        FROM production_stages
        WHERE status != 'Completed' AND assigned_staff_id IS NOT NULL
        GROUP BY assigned_staff_id
        """
    ).fetchall():
        counts_by_staff[row["assigned_staff_id"]] = row["count"]

    unassigned_count = connection.execute(
        """
        SELECT COUNT(*) AS count
        FROM production_stages
        WHERE assigned_staff_id IS NULL AND status != 'Completed'
        """
    ).fetchone()["count"]

    total_assigned_count = sum(counts_by_staff.values())

    connection.close()

    return render_template(
        "assign_work.html",
        staff_members=staff_members,
        assignments=assignments,
        staff_filter=staff_filter,
        counts_by_staff=counts_by_staff,
        unassigned_count=unassigned_count,
        total_assigned_count=total_assigned_count
    )


@app.route("/reports")
def reports():

    start = parse_date_arg(request.args.get("start"))
    end = parse_date_arg(request.args.get("end"))

    connection = get_connection()

    date_clause = ""
    params = []
    if start:
        date_clause += " AND orders.order_date >= ?"
        params.append(start)
    if end:
        date_clause += " AND orders.order_date <= ?"
        params.append(end)

    order_count = connection.execute(
        f"SELECT COUNT(*) FROM orders WHERE 1=1{date_clause}", params
    ).fetchone()[0]

    total_revenue = connection.execute(
        f"""
        SELECT COALESCE(SUM(payments.amount), 0)
        FROM payments
        JOIN orders ON orders.id = payments.order_id
        WHERE 1=1{date_clause.replace('orders.order_date', 'payments.payment_date')}
        """,
        params
    ).fetchone()[0]

    customer_count = connection.execute(
        "SELECT COUNT(*) FROM customers"
    ).fetchone()[0]

    connection.close()

    return render_template(
        "reports.html",
        start=start or "",
        end=end or "",
        order_count=order_count,
        total_revenue=total_revenue,
        customer_count=customer_count
    )


def build_orders_report(connection, start=None, end=None):

    query = """
        SELECT orders.order_number, customers.name AS customer_name,
               customers.phone AS customer_phone, products.name AS product_name,
               orders.order_type, orders.order_date, orders.due_date,
               orders.current_stage, orders.status,
               orders.order_price, orders.deposit_paid
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        LEFT JOIN products ON products.id = orders.product_id
        WHERE 1=1
    """
    params = []
    if start:
        query += " AND orders.order_date >= ?"
        params.append(start)
    if end:
        query += " AND orders.order_date <= ?"
        params.append(end)
    query += " ORDER BY orders.order_date DESC, orders.id DESC"

    order_rows = connection.execute(query, params).fetchall()

    rows = []
    for row in order_rows:
        if row["order_price"] is not None:
            balance_due = round(row["order_price"] - row["deposit_paid"], 2)
            if balance_due <= 0:
                payment_status = "Paid"
            elif row["deposit_paid"] > 0:
                payment_status = "Partial"
            else:
                payment_status = "Unpaid"
        else:
            balance_due = ""
            payment_status = "No Price Set"

        rows.append([
            row["order_number"], row["customer_name"], row["customer_phone"] or "",
            row["product_name"] or "", row["order_type"], row["order_date"] or "",
            row["due_date"] or "", row["current_stage"], row["status"],
            row["order_price"] if row["order_price"] is not None else "",
            row["deposit_paid"], balance_due, payment_status
        ])

    headers = [
        "Order Number", "Customer", "Phone", "Product", "Order Type",
        "Order Date", "Due Date", "Current Stage", "Status",
        "Order Price", "Deposit Paid", "Balance Due", "Payment Status"
    ]

    return headers, rows


def build_payments_report(connection, start=None, end=None):

    query = """
        SELECT payments.payment_date, payments.amount, payments.method,
               payments.notes, orders.order_number, customers.name AS customer_name
        FROM payments
        JOIN orders ON orders.id = payments.order_id
        JOIN customers ON customers.id = orders.customer_id
        WHERE 1=1
    """
    params = []
    if start:
        query += " AND payments.payment_date >= ?"
        params.append(start)
    if end:
        query += " AND payments.payment_date <= ?"
        params.append(end)
    query += " ORDER BY payments.payment_date DESC, payments.id DESC"

    payment_rows = connection.execute(query, params).fetchall()

    rows = [
        [
            row["payment_date"], row["order_number"], row["customer_name"],
            row["amount"], row["method"] or "", row["notes"] or ""
        ]
        for row in payment_rows
    ]

    headers = ["Payment Date", "Order Number", "Customer", "Amount", "Method", "Notes"]

    return headers, rows


def build_customers_report(connection, start=None, end=None):

    customer_rows = connection.execute(
        """
        SELECT customers.name, customers.phone, customers.email,
               COUNT(orders.id) AS order_count,
               COALESCE(SUM(orders.order_price), 0) AS total_order_value,
               COALESCE(SUM(orders.deposit_paid), 0) AS total_paid
        FROM customers
        LEFT JOIN orders ON orders.customer_id = customers.id
        GROUP BY customers.id
        ORDER BY customers.name ASC
        """
    ).fetchall()

    rows = [
        [
            row["name"], row["phone"] or "", row["email"] or "",
            row["order_count"], row["total_order_value"], row["total_paid"],
            round(row["total_order_value"] - row["total_paid"], 2)
        ]
        for row in customer_rows
    ]

    headers = ["Name", "Phone", "Email", "Order Count", "Total Order Value", "Total Paid", "Balance Due"]

    return headers, rows


def build_staff_report(connection, start=None, end=None):

    staff_rows = connection.execute(
        """
        SELECT staff.name, staff.role, staff.active,
               COUNT(production_stages.id) AS assigned_count,
               SUM(CASE WHEN production_stages.status = 'Completed' THEN 1 ELSE 0 END) AS completed_count
        FROM staff
        LEFT JOIN production_stages ON production_stages.assigned_staff_id = staff.id
        GROUP BY staff.id
        ORDER BY staff.name ASC
        """
    ).fetchall()

    rows = [
        [
            row["name"], row["role"] or "",
            "Active" if row["active"] else "Inactive",
            row["assigned_count"], row["completed_count"] or 0
        ]
        for row in staff_rows
    ]

    headers = ["Name", "Role", "Status", "Stages Assigned", "Stages Completed"]

    return headers, rows


def build_vendor_jobs_report(connection, start=None, end=None):

    job_rows = connection.execute(
        """
        SELECT vendor_jobs.*, orders.order_number, customers.name AS customer_name
        FROM vendor_jobs
        JOIN orders ON orders.id = vendor_jobs.order_id
        JOIN customers ON customers.id = orders.customer_id
        ORDER BY vendor_jobs.id DESC
        """
    ).fetchall()

    rows = [
        [
            row["order_number"], row["customer_name"], row["vendor_name"],
            row["work_description"] or "", row["status"],
            row["sent_date"] or "", row["received_date"] or "", row["notes"] or ""
        ]
        for row in job_rows
    ]

    headers = [
        "Order Number", "Customer", "Vendor", "Work Description",
        "Status", "Sent Date", "Received Date", "Notes"
    ]

    return headers, rows


def build_stone_transactions_report(connection, start=None, end=None):

    stone_rows = connection.execute(
        """
        SELECT stone_transactions.*, orders.order_number, customers.name AS customer_name
        FROM stone_transactions
        JOIN orders ON orders.id = stone_transactions.order_id
        JOIN customers ON customers.id = orders.customer_id
        ORDER BY stone_transactions.id DESC
        """
    ).fetchall()

    rows = [
        [
            row["order_number"], row["customer_name"], row["transaction_type"] or "",
            row["stone_type"] or "", row["shape"] or "", row["color"] or "",
            row["clarity"] or "", row["vendor_name"] or "", row["quantity"] or "",
            row["carat"] or "", row["transaction_date"] or "", row["pickup_date"] or "",
            row["notes"] or ""
        ]
        for row in stone_rows
    ]

    headers = [
        "Order Number", "Customer", "Type", "Stone Type", "Shape", "Color",
        "Clarity", "Vendor", "Quantity", "Carat", "Transaction Date",
        "Pickup Date", "Notes"
    ]

    return headers, rows


# Registry shared between the logged-in CSV export routes and the public
# token-gated "live data link" routes below, so both always show the
# exact same data per report.
REPORT_BUILDERS = {
    "Orders": build_orders_report,
    "Payments": build_payments_report,
    "Customers": build_customers_report,
    "Staff": build_staff_report,
    "Vendor Jobs": build_vendor_jobs_report,
    "Stone Transactions": build_stone_transactions_report,
}

# URL-friendly key -> report label, for the public /data/<token>/<key>.csv
# links a spreadsheet's IMPORTDATA() formula points at.
DATA_LINK_REPORTS = [
    ("orders", "Orders"),
    ("payments", "Payments"),
    ("customers", "Customers"),
    ("staff", "Staff"),
    ("vendor-jobs", "Vendor Jobs"),
    ("stone-transactions", "Stone Transactions"),
]

DATA_LINK_KEY_TO_TAB = dict(DATA_LINK_REPORTS)


def get_or_create_data_link_token(connection):
    """Every installation gets one long random secret token. Anyone
    who has it can read (but not write) the six reports below without
    logging in - that's what lets Google Sheets' IMPORTDATA() pull
    live data on a schedule. Generated once, regenerable from Settings
    if it's ever exposed."""

    settings_row = get_settings_row(connection)

    if settings_row and settings_row["data_link_token"]:
        return settings_row["data_link_token"]

    token = secrets.token_urlsafe(24)

    connection.execute(
        "UPDATE settings SET data_link_token = ? WHERE id = 1",
        (token,)
    )
    connection.commit()

    return token


@app.route("/data/<token>/<report_key>.csv")
def public_data_csv(token, report_key):
    """Unauthenticated CSV export, gated by the secret token instead of
    a login session - this is the URL a Google Sheets IMPORTDATA()
    formula fetches. Returns a plain 404 for a wrong/missing token or
    unknown report key, revealing nothing about which part failed."""

    if report_key not in DATA_LINK_KEY_TO_TAB:
        return ("Not found", 404)

    connection = get_connection()
    settings_row = get_settings_row(connection)

    if not settings_row or not settings_row["data_link_token"] \
            or not secrets.compare_digest(settings_row["data_link_token"], token):
        connection.close()
        return ("Not found", 404)

    tab_name = DATA_LINK_KEY_TO_TAB[report_key]
    headers, rows = REPORT_BUILDERS[tab_name](connection)
    connection.close()

    return csv_response(f"{report_key.replace('-', '_')}_report.csv", headers, rows)


@app.route("/reports/master")
def master_report():
    """One page per order: full order detail (current stage, status,
    dates, price/payment), plus every photo ever uploaded against it -
    the cover photo, the order's photo gallery, and any stone-management
    photos/invoices - all in one place. Meant to be scrolled through or
    printed (Ctrl/Cmd+P - the sidebar and buttons are hidden when
    printing)."""

    search_query = request.args.get("q", "").strip()
    stage_filter = request.args.get("stage", "").strip()
    order_filter = request.args.get("filter", "").strip()

    connection = get_connection()

    base_query = """
        SELECT orders.*, customers.name AS customer_name,
               customers.phone AS customer_phone, products.name AS product_name
        FROM orders
        JOIN customers ON customers.id = orders.customer_id
        LEFT JOIN products ON products.id = orders.product_id
    """

    conditions = []
    params = []

    today = date.today().isoformat()

    if search_query:
        conditions.append(
            "(orders.order_number LIKE ? OR customers.name LIKE ? "
            "OR orders.product_number LIKE ? OR products.name LIKE ? "
            "OR customers.phone LIKE ?)"
        )
        like_term = f"%{search_query}%"
        params.extend([like_term, like_term, like_term, like_term, like_term])

    if stage_filter:
        conditions.append(
            """
            EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.stage_name = ?
                AND production_stages.status != 'Completed'
            )
            """
        )
        params.append(stage_filter)
    elif order_filter == "in_progress":
        conditions.append(
            """
            EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.status = 'In Progress'
            )
            """
        )
    elif order_filter == "not_started":
        conditions.append(
            """
            NOT EXISTS (
                SELECT 1 FROM production_stages
                WHERE production_stages.order_id = orders.id
                AND production_stages.status IN ('In Progress', 'Completed')
            )
            """
        )
    elif order_filter == "finished":
        conditions.append("orders.status = 'Completed'")
    elif order_filter == "overdue":
        conditions.append(
            "orders.due_date IS NOT NULL AND orders.due_date != '' "
            "AND orders.due_date < ? AND orders.status != 'Completed'"
        )
        params.append(today)

    if conditions:
        base_query += " WHERE " + " AND ".join(conditions)

    base_query += " ORDER BY orders.id DESC"

    order_rows = connection.execute(base_query, params).fetchall()
    order_ids = [row["id"] for row in order_rows]

    order_photos_by_order = {}
    stone_photos_by_order = {}

    if order_ids:

        placeholders = ",".join("?" for _ in order_ids)

        for photo_row in connection.execute(
            f"""
            SELECT * FROM order_photos
            WHERE order_id IN ({placeholders})
            ORDER BY id ASC
            """,
            order_ids
        ).fetchall():
            order_photos_by_order.setdefault(photo_row["order_id"], []).append(photo_row)

        for stone_row in connection.execute(
            f"""
            SELECT * FROM stone_transactions
            WHERE order_id IN ({placeholders})
            ORDER BY id ASC
            """,
            order_ids
        ).fetchall():
            stone_photos_by_order.setdefault(stone_row["order_id"], []).append(stone_row)

    connection.close()

    orders_with_photos = []

    for order in order_rows:

        seen_paths = set()
        photos = []

        def add_photo(path, label):
            if not path or path in seen_paths:
                return
            seen_paths.add(path)
            photos.append({"path": path, "label": label, "is_image": is_image_path(path)})

        add_photo(order["photo_path"], "Cover Photo")

        for photo_row in order_photos_by_order.get(order["id"], []):
            add_photo(photo_row["photo_path"], photo_row["caption"] or "Order Photo")

        for stone_row in stone_photos_by_order.get(order["id"], []):
            stone_label = "Stone Photo"
            if stone_row["stone_type"]:
                stone_label = f"Stone Photo - {stone_row['stone_type']}"
            add_photo(stone_row["photo_path"], stone_label)
            add_photo(stone_row["invoice_path"], "Stone Invoice")

        if order["order_price"] is not None:
            balance_due = round(order["order_price"] - order["deposit_paid"], 2)
            if balance_due <= 0:
                payment_status = "Paid"
            elif order["deposit_paid"] > 0:
                payment_status = "Partial"
            else:
                payment_status = "Unpaid"
        else:
            balance_due = None
            payment_status = "No Price Set"

        orders_with_photos.append({
            "order": order,
            "photos": photos,
            "balance_due": balance_due,
            "payment_status": payment_status
        })

    return render_template(
        "master_report.html",
        orders_with_photos=orders_with_photos,
        search_query=search_query,
        stage_filter=stage_filter,
        order_filter=order_filter,
        today=today,
        stages=STAGES
    )


@app.route("/reports/orders.csv")
def report_orders_csv():

    start = parse_date_arg(request.args.get("start"))
    end = parse_date_arg(request.args.get("end"))

    connection = get_connection()
    headers, rows = build_orders_report(connection, start, end)
    connection.close()

    return csv_response("orders_report.csv", headers, rows)


@app.route("/reports/payments.csv")
def report_payments_csv():

    start = parse_date_arg(request.args.get("start"))
    end = parse_date_arg(request.args.get("end"))

    connection = get_connection()
    headers, rows = build_payments_report(connection, start, end)
    connection.close()

    return csv_response("payments_report.csv", headers, rows)


@app.route("/reports/customers.csv")
def report_customers_csv():

    connection = get_connection()
    headers, rows = build_customers_report(connection)
    connection.close()

    return csv_response("customers_report.csv", headers, rows)


@app.route("/reports/staff.csv")
def report_staff_csv():

    connection = get_connection()
    headers, rows = build_staff_report(connection)
    connection.close()

    return csv_response("staff_report.csv", headers, rows)


@app.route("/reports/vendor-jobs.csv")
def report_vendor_jobs_csv():

    connection = get_connection()
    headers, rows = build_vendor_jobs_report(connection)
    connection.close()

    return csv_response("vendor_jobs_report.csv", headers, rows)


@app.route("/reports/stone-transactions.csv")
def report_stone_transactions_csv():

    connection = get_connection()
    headers, rows = build_stone_transactions_report(connection)
    connection.close()

    return csv_response("stone_transactions_report.csv", headers, rows)


@app.route("/todos/<int:todo_id>/restore", methods=["POST"])
def restore_todo(todo_id):

    connection = get_connection()

    connection.execute(
        """
        UPDATE todos
        SET archived = 0, archived_at = NULL
        WHERE id = ? AND archived = 1
        """,
        (todo_id,)
    )

    connection.commit()
    connection.close()

    return redirect(url_for("archived_todos"))


if __name__ == "__main__":

    # FLASK_DEBUG=1 locally for auto-reload + debugger.
    # Leave it unset (the default) anywhere the app is actually deployed.
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"

    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 5000)),
        debug=debug_mode
    )
